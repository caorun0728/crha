# Auto install Shadowsocks Server

## shadowsocks.sh

> Description: Auto Install Shadowsocks(Python) Server for CentOS/Redhat/Fedora/Debian/Ubuntu
> 
> Intro: https://teddysun.com/342.html

## shadowsocks-libev.sh

> Description: Auto Install Shadowsocks(libev) Server for CentOS/Redhat/Fedora
> 
> Intro: https://teddysun.com/357.html

## shadowsocks-libev-debian.sh

> Description: Auto Install Shadowsocks(libev) Server for Debian/Ubuntu
> 
> Intro: https://teddysun.com/358.html

## shadowsocks-go.sh

> Description: Auto Install Shadowsocks(Go) Server for CentOS/Redhat/Fedora/Debian/Ubuntu
> 
> Intro: https://teddysun.com/392.html

## shadowsocks-crond.sh

> Description: Check Shadowsocks(All version) Server is running or not, and start it if not running
> 
> Intro: https://shadowsocks.be/6.html

## shadowsocksR.sh

> Description: Auto Install ShadowsocksR Server for CentOS/Redhat/Fedora/Debian/Ubuntu
> 
> Intro: https://shadowsocks.be/9.html

## shadowsocks-nodejs.sh (Deprecated)

> Description: Auto Install Shadowsocks(NodeJS) Server for CentOS/Redhat/Fedora
> 
> Intro: https://teddysun.com/355.html

Copyright (C) 2014-2016 Teddysun <i@teddysun.com>