#!/bin/sh
ln -s /tmp/data/python2.7 /usr/lib/python2.7
ln -s /tmp/data/python2 /usr/bin/python



