#!/bin/sh
ln -s /tmp/data/python2.7 /usr/lib/python2.7
ln -s /tmp/data/python2 /usr/bin/python
ln -s /etc/init.d/syncy /etc/rc.d/S99syncy
/etc/init.d/syncy enable
python /usr/bin/syncy.py


